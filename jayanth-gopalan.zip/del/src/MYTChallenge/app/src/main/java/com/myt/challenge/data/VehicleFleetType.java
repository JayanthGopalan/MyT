package com.myt.challenge.data;

/**
 * Enum that represents the fleet type of a vehicle
 */
public enum VehicleFleetType {
    POOLING, TAXI, UNKNOWN
}
