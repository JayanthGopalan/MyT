package com.myt.challenge.data;

import com.google.android.gms.maps.model.LatLng;
import com.myt.challenge.AppConstants;

import java.util.Random;

/**
 * Java object class that holds individual vehicle data
 */
public class VehicleData {

    /**
     * Unique ID of a vehicle
     */
    private int mId = -1;

    /**
     * Represents the vehicle brand name, generated randomly
     */
    private String mVehicleName;

    /**
     * Indicates the current {@link LatLng} of the vehicle
     */
    private LatLng mLocation;

    /**
     * Indicates the {@link VehicleFleetType}
     */
    private VehicleFleetType mVehicleFleetType;

    /**
     * Direction in which the vehicle is heading towards to.
     */
    private double mHeading;

    /**
     * Rating of a vehicle, generated randomly.
     */
    private float mRating;

    public VehicleData(int id, LatLng location, VehicleFleetType vehicleFleetType, double heading) {
        setId(id);
        setLocation(location);
        setFleetType(vehicleFleetType);
        setVehicleName(getRandomVehicleName(vehicleFleetType));
        setHeading(heading);
        setRating(generateRandomRating());
    }

    public LatLng getLocation() {
        return mLocation;
    }

    private void setLocation(LatLng location) {
        this.mLocation = location;
    }

    public int getId() {
        return mId;
    }

    private void setId(int id) {
        this.mId = id;
    }

    public String getVehicleName() {
        return mVehicleName;
    }

    private void setVehicleName(String title) {
        this.mVehicleName = title;
    }

    public VehicleFleetType getFleetType() {
        return mVehicleFleetType;
    }

    private void setFleetType(VehicleFleetType vehicleFleetType) {
        this.mVehicleFleetType = vehicleFleetType;
    }

    public double getHeading() {
        return mHeading;
    }

    private void setHeading(double heading) {
        this.mHeading = heading;
    }

    private void setRating(float randomRating) {
        this.mRating = randomRating;
    }

    public float getRating() {
        return mRating;
    }

    /**
     * API to generate a random user rating for a vehicle
     *
     * @return random user rating
     */
    private float generateRandomRating() {
        Random random = new Random();
        return random.nextInt(5);
    }

    /**
     * API to generate a random name for a vehicle
     *
     * @param vehicleFleetType : {@link VehicleFleetType} of a vehicle
     * @return random name for a vehicle
     */
    private String getRandomVehicleName(VehicleFleetType vehicleFleetType) {
        return AppConstants.VehicleTitleGenerator.anyVehicle(vehicleFleetType);
    }

    @Override
    public String toString() {
        return "[" + "mId = " + getId() + "\t" + "VehicleFleetType=" + getFleetType() + "]";
    }

}
