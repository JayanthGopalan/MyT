package com.myt.challenge;

import android.util.Log;

/**
 * Util class to print logs
 */
public final class PrintLog {

    /**
     * Constant that defines the log tag printed in console
     */
    private static final String LOG_TAG = "My-Taxi-CodingChallenge";

    /**
     * Constant that defines if debug mode is enabled (or) not
     */
    private static boolean DEBUG = true;

    /**
     * API to print verbose logs to console
     *
     * @param msg : Log message
     */
    public static void v(Object... msg) {
        if (DEBUG) Log.v(LOG_TAG, constructLogPrint(msg));
    }

    /**
     * API to print info logs to console
     *
     * @param msg : Log message
     */
    public static void i(Object... msg) {
        if (DEBUG) Log.i(LOG_TAG, constructLogPrint(msg));
    }

    /**
     * API to print debug logs to console
     *
     * @param msg : Log message
     */
    public static void d(Object... msg) {
        if (DEBUG) Log.d(LOG_TAG, constructLogPrint(msg));
    }

    /**
     * API to print warning logs to console
     *
     * @param msg : Log message
     */
    public static void w(Object... msg) {
        if (DEBUG) Log.w(LOG_TAG, constructLogPrint(msg));
    }

    /**
     * API to print error logs to console
     *
     * @param msg : Log message
     */
    public static void e(Object... msg) {
        if (DEBUG) Log.e(LOG_TAG, constructLogPrint(msg));
    }

    /**
     * API used to construct the logs in a defined format before printing to console
     *
     * @param msg : Log message
     * @return formatted log message
     */
    private static String constructLogPrint(Object... msg) {
        StringBuilder logPrint = new StringBuilder("");
        if (null != msg) {
            for (Object item : msg) {
                logPrint.append(item);
            }
        }
        return logPrint.toString();
    }

}
