package com.myt.challenge.ui.fragment;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.myt.challenge.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.google.android.gms.maps.model.BitmapDescriptorFactory.HUE_RED;
import static com.myt.challenge.AppConstants.HAMBURG_COORDINATE_BOUNDS;

/**
 * Util class for Map data operations
 */
public final class MapUtil {

    private MapUtil() {
    }

    /**
     * API to zoom the map as per the given coordinate bounds
     *
     * @param map              : reference of {@link GoogleMap}
     * @param latLngBoundsList : coordinate bounds to zoomed-in
     */
    public static void zoomMapByBoundsList(GoogleMap map, List<LatLng> latLngBoundsList) {
        if (map == null || latLngBoundsList == null || latLngBoundsList.isEmpty()) return;

        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
        for (LatLng latLngPoint : latLngBoundsList) {
            boundsBuilder.include(latLngPoint);
        }
        int routePadding = 100;
        LatLngBounds latLngBounds = boundsBuilder.build();

        map.moveCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds, routePadding));
    }

    /**
     * API to zoom the map in the bounds of Hamburg coordinates
     *
     * @param map : reference of {@link GoogleMap}
     */
    public static void zoomToHamburgBounds(GoogleMap map) {
        Objects.requireNonNull(map);
        List<LatLng> bounds = new ArrayList<>();
        bounds.add(HAMBURG_COORDINATE_BOUNDS.first);
        bounds.add(HAMBURG_COORDINATE_BOUNDS.second);
        zoomMapByBoundsList(map, bounds);
    }

    /**
     * API to locate a vehicle on the map
     *
     * @param context  : App context
     * @param map      : reference of {@link GoogleMap}
     * @param location : coordinates of the vehicle
     * @param title    : vehicle name
     * @param snippet  : vehicle description if any
     * @param rotation : direction
     */
    public static void locateOnMap(Context context, GoogleMap map, LatLng location, String title, String snippet,
                                   float rotation) {
        if (null == context || null == map || null == location) {
            return;
        }
        if (null == title) title = "";
        if (null == snippet) snippet = "";
        BitmapDescriptor bitmapDescriptor;
        if (null == (bitmapDescriptor = fromVector(context, R.drawable.ic_navigation))) {
            bitmapDescriptor = BitmapDescriptorFactory.defaultMarker(HUE_RED);
        }
        Marker marker = map.addMarker(new MarkerOptions().position(location).title(title).snippet(snippet)
                .icon(bitmapDescriptor).flat(true));
        marker.setRotation(rotation);
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 13));
    }

    /**
     * API that converts a vector drawable to
     *
     * @param context     : App context
     * @param vectorResId : res Id of the vector drawable
     * @return {@link BitmapDescriptor}
     */
    private static BitmapDescriptor fromVector(Context context, int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        if (null != vectorDrawable) {
            vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
            Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            vectorDrawable.draw(canvas);
            return BitmapDescriptorFactory.fromBitmap(bitmap);
        }
        return null;
    }

}
