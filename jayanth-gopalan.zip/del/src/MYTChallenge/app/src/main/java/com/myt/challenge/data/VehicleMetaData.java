package com.myt.challenge.data;

import com.myt.challenge.PrintLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Class that holds all data for vehicle fleet types
 */
public class VehicleMetaData {

    /**
     * {@link List} that holds the {@link VehicleData} for all {@code VehicleFleetType.TAXI} vehicle types
     */
    private List<VehicleData> mTaxiVehicleData;

    /**
     * {@link List} that holds the {@link VehicleData} for all {@code VehicleFleetType.POOLING} vehicle types
     */
    private List<VehicleData> mPoolingVehicleData;

    VehicleMetaData() {
        mPoolingVehicleData = new ArrayList<>();
        mTaxiVehicleData = new ArrayList<>();
    }

    /**
     * API to add a {@link VehicleData} to the local list maintained internally
     * that is segregated by {@link VehicleFleetType}
     *
     * @param vehicleData      : {@link VehicleData} to be added
     * @param vehicleFleetType : Intended {@link VehicleFleetType}
     */
    public void add(VehicleData vehicleData, VehicleFleetType vehicleFleetType) {
        switch (vehicleFleetType) {
            case POOLING:
                mPoolingVehicleData.add(vehicleData);
                break;
            case TAXI:
                mTaxiVehicleData.add(vehicleData);
                break;

            default:
                PrintLog.d("Unknown vehicleFleetType..  ignored");
                break;
        }
    }

    /**
     * API to reset and clear all available {@link VehicleData} for all {@link VehicleFleetType}
     */
    public void reset() {
        if (null != mTaxiVehicleData) mTaxiVehicleData.clear();
        if (null != mPoolingVehicleData) mPoolingVehicleData.clear();
    }

    /**
     * API to get a specific list of {@link VehicleData} filtered by {@link VehicleFleetType}
     *
     * @param fleetType : Intended {@link VehicleFleetType}
     * @return {@link List} containing {@link VehicleData} for intended {@link VehicleFleetType}
     */
    public List<VehicleData> getVehicleList(VehicleFleetType fleetType) {
        List<VehicleData> vehicleDataList = null;
        if (null != fleetType) {
            switch (fleetType) {
                case POOLING:
                    vehicleDataList = mPoolingVehicleData;
                    break;

                case TAXI:
                    vehicleDataList = mTaxiVehicleData;
                    break;
            }
        }
        return vehicleDataList;
    }

    /**
     * API to check if {@link VehicleData} for all {@link VehicleFleetType} is empty
     *
     * @return true if {@link VehicleData} for all {@link VehicleFleetType} is empty, else falses
     */
    public boolean isEmpty() {
        return (mTaxiVehicleData.isEmpty() && mPoolingVehicleData.isEmpty());
    }

    /**
     * API that combines the {@link VehicleData} for all {@link VehicleFleetType} and returns the count
     *
     * @return total count of the {@link VehicleData} available
     */
    public int getTotalVehicleCount() {
        int totalVehicleCount = 0;
        if (null != mPoolingVehicleData) {
            totalVehicleCount += mPoolingVehicleData.size();
        }
        if (null != mTaxiVehicleData) {
            totalVehicleCount += mTaxiVehicleData.size();
        }
        return totalVehicleCount;
    }

    /**
     * API that combines the {@link VehicleData} for all {@link VehicleFleetType}
     *
     * @return {@link List} that contains all {@link VehicleData}
     */
    public List<VehicleData> getAllVehicleData() {
        List<VehicleData> dataList = new ArrayList<>();
        if (null != mTaxiVehicleData) dataList.addAll(mTaxiVehicleData);
        if (null != mPoolingVehicleData) dataList.addAll(mPoolingVehicleData);
        return dataList;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return "mTaxiVehicleData :: " + mTaxiVehicleData + "\n\nmPoolingVehicleData :: " + mPoolingVehicleData;
    }

}
