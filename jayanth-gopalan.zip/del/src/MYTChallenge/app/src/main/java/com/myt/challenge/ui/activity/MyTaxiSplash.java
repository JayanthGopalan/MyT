package com.myt.challenge.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.myt.challenge.R;

import static com.myt.challenge.AppConstants.SPLASH_TIME_OUT;

/**
 * Activity that displays the App splash
 */
public class MyTaxiSplash extends AppCompatActivity {

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_layout);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onStart() {
        super.onStart();
        runSplash();
    }

    /**
     * API that runs the App splash
     */
    private void runSplash() {
        new Handler().postDelayed(() -> {
            // This method will be executed once the timer is fired
            Intent intent = new Intent(getApplicationContext(), DeveloperInfoPage.class);
            startActivity(intent);
            // close this activity
            finish();
        }, SPLASH_TIME_OUT);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onBackPressed() {
        // disable BACK key for splash screen
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

}
