package com.myt.challenge.ui.activity;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import com.myt.challenge.R;
import com.myt.challenge.data.VehicleDataProvider;
import com.myt.challenge.ui.fragment.MyTaxiFragmentBase;
import com.myt.challenge.ui.fragment.VehicleListViewAsyncFragment;
import com.myt.challenge.ui.fragment.VehicleMapFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity that is the main screen for the App
 */
public class MyTaxiMainScreen extends AppCompatActivity {

    /**
     * {@link Toolbar} reference of the App's main screen
     */
    private Toolbar mToolbar;

    /**
     * {@link TabLayout} reference of the App's main screen
     */
    private TabLayout mTabLayout;

    /**
     * {@link ViewPager} reference of the App's main screen
     */
    private ViewPager mViewPager;

    /**
     * {@link ArrayList} that holds the fragments that were inflated on the App's main screen
     */
    private List<MyTaxiFragmentBase> mFragmentList;

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mFragmentList = new ArrayList<>();
        mToolbar = findViewById(R.id.toolbar);
        mToolbar.setTitle(getString(R.string.solutions));
        setSupportActionBar(mToolbar);

        if (null != getSupportActionBar()) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Setup with view pager
        mViewPager = findViewById(R.id.container);
        setupViewPager(mViewPager);

        // Setup tab layout
        mTabLayout = findViewById(R.id.tabs);
        mTabLayout.setupWithViewPager(mViewPager);
        setupTabIcons();

        // Add OnPageChangeListener for the main screen's view pager widget
        mViewPager.addOnPageChangeListener(
                new ViewPager.SimpleOnPageChangeListener() {
                    @Override
                    public void onPageSelected(int position) {
                        for (int tabIndex = 0; tabIndex < mTabLayout.getTabCount(); tabIndex++) {
                            TabLayout.Tab tab = (mTabLayout.getTabAt(position));
                            if (null != tab) {
                                tab.select();
                            }
                        }
                    }
                });
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    /**
     * API to set icon for each {@link TabLayout} on UI
     */
    private void setupTabIcons() {
        for (int tabIndex = 0; tabIndex < mTabLayout.getTabCount(); tabIndex++) {
            TabLayout.Tab tab = (mTabLayout.getTabAt(tabIndex));
            if (null != tab) {
                tab.setIcon(mFragmentList.get(tabIndex).getDisplayIconId());
            }
        }
    }

    /**
     * API to setup {@link ViewPager} on UI
     *
     * @param viewPager : reference of the {@link ViewPager} on the App's main screen
     */
    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());

        VehicleListViewAsyncFragment vehicleListViewAsyncFragment = new VehicleListViewAsyncFragment();
        mFragmentList.add(vehicleListViewAsyncFragment);
        adapter.addFragment(vehicleListViewAsyncFragment, getString(R.string.vehicle_list));

        VehicleMapFragment vehicleMapFragment = new VehicleMapFragment();
        mFragmentList.add(vehicleMapFragment);
        adapter.addFragment(vehicleMapFragment, getString(R.string.locate_vehicle));

        // Set the view pager adapter to display all the fragments initialized
        viewPager.setAdapter(adapter);
    }

    /**
     * Adapter class that helps to display all fragments on UI
     */
    private class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        /**
         * API to add a fragment
         *
         * @param fragment : {@link Fragment} reference
         * @param title    : Fragment name
         */
        void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onStop() {
        if (null != VehicleDataProvider.getVehicleMetaData()) {
            VehicleDataProvider.getVehicleMetaData().reset();
        }
        super.onStop();
    }

}
