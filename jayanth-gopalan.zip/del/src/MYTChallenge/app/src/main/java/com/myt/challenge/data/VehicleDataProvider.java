package com.myt.challenge.data;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.maps.model.LatLng;
import com.myt.challenge.AppController;
import com.myt.challenge.PrintLog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.LinkedBlockingQueue;

import static com.myt.challenge.AppConstants.HAMBURG_QUERY_URL_DATA;
import static com.myt.challenge.AppConstants.KEY_COORDINATE;
import static com.myt.challenge.AppConstants.KEY_FLEET_TYPE;
import static com.myt.challenge.AppConstants.KEY_HEADING;
import static com.myt.challenge.AppConstants.KEY_ID;
import static com.myt.challenge.AppConstants.KEY_LATITUDE;
import static com.myt.challenge.AppConstants.KEY_LONGITUDE;
import static com.myt.challenge.AppConstants.KEY_POI_LIST;
import static com.myt.challenge.AppConstants.MAX_THREAD_WAIT;
import static com.myt.challenge.data.VehicleFleetType.POOLING;
import static com.myt.challenge.data.VehicleFleetType.TAXI;
import static com.myt.challenge.data.VehicleFleetType.UNKNOWN;
import static java.net.HttpURLConnection.HTTP_BAD_GATEWAY;
import static java.net.HttpURLConnection.HTTP_BAD_METHOD;
import static java.net.HttpURLConnection.HTTP_BAD_REQUEST;
import static java.net.HttpURLConnection.HTTP_CLIENT_TIMEOUT;
import static java.net.HttpURLConnection.HTTP_CONFLICT;
import static java.net.HttpURLConnection.HTTP_FORBIDDEN;
import static java.net.HttpURLConnection.HTTP_GATEWAY_TIMEOUT;
import static java.net.HttpURLConnection.HTTP_GONE;
import static java.net.HttpURLConnection.HTTP_INTERNAL_ERROR;
import static java.net.HttpURLConnection.HTTP_NOT_ACCEPTABLE;
import static java.net.HttpURLConnection.HTTP_NOT_FOUND;
import static java.net.HttpURLConnection.HTTP_REQ_TOO_LONG;

/**
 * Class that provides vehicle data fetched from remote server
 */
public class VehicleDataProvider {

    /**
     * {@link Queue} that contains all the pending outgoing network requests
     */
    private static Queue<PendingDataFetch> sPendingRequestQueue = new LinkedBlockingQueue<>(100);

    /**
     * {@link Object} instance that is used for thread lock
     */
    private static final Object sLock = new Object();

    /**
     * value that is assigned to every outgoing network request
     */
    private static int sRequestId = 0;

    /**
     * Instance of {@link VehicleMetaData} to hold {@link VehicleData}
     */
    private static VehicleMetaData sVehicleMetaData = new VehicleMetaData();

    private VehicleDataProvider() {
    }

    /**
     * Callback interface that clients need to implement to get server response/error
     */
    public interface VehicleDataProviderCallback {
        /**
         * API that will be called in event of a sever response
         *
         * @param vehicleMetaData : {@link VehicleData} sent by the server
         */
        void onResponse(VehicleMetaData vehicleMetaData);

        /**
         * API that will be called in event of a sever response
         *
         * @param errorMsg : Error message from the server
         */
        void onError(String errorMsg);
    }

    /**
     * API to get the {@link VehicleMetaData} fetched from remote server
     *
     * @return {@link VehicleMetaData} fetched from remote server
     */
    public static VehicleMetaData getVehicleMetaData() {
        return sVehicleMetaData;
    }

    /**
     * API to fetch {@link VehicleData} fetched from remote server for Hamburg city.
     * <p>This is a default API</p>
     *
     * @param vehicleDataProviderCallback : callback interface to be provided by clients for server
     *                                    response/error results to be sent back to client
     */
    public static void fetchVehicleDataFromRemoteServer(VehicleDataProviderCallback vehicleDataProviderCallback) {
        fetchVehicleDataFromRemoteServer(HAMBURG_QUERY_URL_DATA, vehicleDataProviderCallback);
    }

    /**
     * API to fetch {@link VehicleData} fetched from remote server for Hamburg city.
     * <p>This is a default API</p>
     *
     * @param url                         : query url of the remote server for particular coordinates
     * @param vehicleDataProviderCallback : callback interface to be provided by clients for server
     *                                    response/error results to be sent back to client
     */
    public static void fetchVehicleDataFromRemoteServer(String url, VehicleDataProviderCallback
            vehicleDataProviderCallback) {
        cancelPendingRequests();
        sVehicleMetaData.reset();
        new Thread(() -> {
            try {
                CompletableFuture<Void> dataFetchFuture = CompletableFuture.supplyAsync(() -> {
                    fetchVehicleDataFromServer(url, vehicleDataProviderCallback);
                    return null;
                });
                sPendingRequestQueue.add(new PendingDataFetch(dataFetchFuture, String.valueOf(++sRequestId)));
                // thread waits here until response/error/timeout from server is seen
                dataFetchFuture.get();
                sPendingRequestQueue.poll();
            } catch (InterruptedException | ExecutionException | CancellationException e) {
                PrintLog.e("Exception encountered in fetch()\n", e.getMessage());
            }
        }).start();
    }

    /**
     * API to cancel all pending requests to server
     */
    private static void cancelPendingRequests() {
        for (PendingDataFetch pendingDataFetch : sPendingRequestQueue) {
            pendingDataFetch.getFuture().cancel(true);
            PrintLog.d("requesting for cancellation of " + pendingDataFetch.getTag() + " from pending queue");
            AppController.getInstance().cancelPendingRequests(pendingDataFetch.getTag());
        }
    }

    /**
     * Internal API to fetch data from remote server
     *
     * @param url                         : query url of the remote server
     * @param vehicleDataProviderCallback : callback interface to be provided by clients for server
     *                                    response/error results to be sent back to client
     */
    private static void fetchVehicleDataFromServer(String url, VehicleDataProviderCallback
            vehicleDataProviderCallback) {
        // Ideally, only one type of data should be fetched here
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    PrintLog.d("received response from server");
                    synchronized (sLock) {
                        sLock.notifyAll();
                    }
                    VehicleMetaData vehicleMetaData = processResponse(response);
                    vehicleDataProviderCallback.onResponse(vehicleMetaData);
                },
                error -> {
                    PrintLog.d("received error from server");
                    PrintLog.e("error::", error);
                    synchronized (sLock) {
                        sLock.notifyAll();
                    }
                    if (null != error) {
                        PrintLog.e("error.networkResponse::", error.networkResponse);
                        String errorMsg;
                        if (null != error.networkResponse) {
                            PrintLog.e("error::", error.networkResponse.statusCode);
                            errorMsg = getErrorMessageByCode(error.networkResponse.statusCode);
                        } else {
                            errorMsg = "Unknown error.";
                        }
                        vehicleDataProviderCallback.onError(errorMsg);
                    }
                });
        AppController.getInstance().addToRequestQueue(stringRequest);
        try {
            PrintLog.d("Thread waiting for server response");
            synchronized (sLock) {
                sLock.wait(MAX_THREAD_WAIT);
            }
            PrintLog.d("Thread wait ended");
        } catch (InterruptedException e) {
            PrintLog.e("InterruptedException encountered in fetchVehicleDataFromServer()");
        }
    }

    /**
     * API to process the response that was sent by the remote server
     *
     * @param response : response sent by the remote server
     * @return processed remote server response wrapped as {@link VehicleMetaData}
     */
    private static VehicleMetaData processResponse(String response) {
        PrintLog.d("processResponse()");
        if (null != sVehicleMetaData) sVehicleMetaData.reset();
        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray array = jsonObject.getJSONArray(KEY_POI_LIST);
            for (int responseIndex = 0; responseIndex < array.length(); responseIndex++) {
                JSONObject item = array.getJSONObject(responseIndex);
                VehicleData vehicleData = new VehicleData(item.getInt(KEY_ID),
                        extractLocation(item.getJSONObject(KEY_COORDINATE)),
                        decodeFleetType(item.getString(KEY_FLEET_TYPE)),
                        (double) item.get(KEY_HEADING));
                sVehicleMetaData.add(vehicleData, vehicleData.getFleetType());
            }
            PrintLog.d("mVehicleDataList :" + sVehicleMetaData);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return sVehicleMetaData;
    }

    /**
     * API to extract the location coordinates from the JSON object response of the remote server
     *
     * @param locationDataObject : JSON object response of the remote server
     * @return {@link LatLng} returned by the remote server
     * @throws JSONException
     */
    private static LatLng extractLocation(JSONObject locationDataObject) throws JSONException {
        LatLng locationData = null;
        if (null != locationDataObject) {
            locationData = new LatLng(locationDataObject.getDouble(KEY_LATITUDE),
                    locationDataObject.getDouble(KEY_LONGITUDE));
        }
        return locationData;
    }

    /**
     * APi to decode the fleet type of a particular vehicle
     *
     * @param fleetInfo : JSON object response of the remote server
     * @return {@link VehicleFleetType} returned by the remote server
     */
    private static VehicleFleetType decodeFleetType(String fleetInfo) {
        VehicleFleetType vehicleFleetType;
        if (null != fleetInfo) {
            if (fleetInfo.equalsIgnoreCase(POOLING.name())) {
                vehicleFleetType = POOLING;
            } else {
                vehicleFleetType = TAXI;
            }
        } else {
            vehicleFleetType = UNKNOWN;
        }
        return vehicleFleetType;
    }

    /**
     * Internal class that holds data related to a outgoing network request
     */
    private static class PendingDataFetch {

        /**
         * Reference of {@link CompletableFuture} where the data from remote server will be stored
         */
        private CompletableFuture mCompletableFuture;

        /**
         * Tag given for every outgoing network request
         */
        private String mTag;

        PendingDataFetch(CompletableFuture completableFuture, String tag) {
            mCompletableFuture = completableFuture;
            mTag = tag;
        }

        CompletableFuture getFuture() {
            return this.mCompletableFuture;
        }

        String getTag() {
            return this.mTag;
        }
    }

    /**
     * API to get the error message using a particular server error code
     *
     * @param errorCode : server error code
     * @return : error message
     */
    private static String getErrorMessageByCode(int errorCode) {
        String errorMessage;
        switch (errorCode) {
            case HTTP_BAD_GATEWAY:
                errorMessage = "HTTP_BAD_GATEWAY";
                break;
            case HTTP_BAD_METHOD:
                errorMessage = "HTTP_BAD_METHOD";
                break;
            case HTTP_BAD_REQUEST:
                errorMessage = "HTTP_BAD_REQUEST";
                break;
            case HTTP_CLIENT_TIMEOUT:
                errorMessage = "HTTP_CLIENT_TIMEOUT";
                break;
            case HTTP_CONFLICT:
                errorMessage = "HTTP_CONFLICT";
                break;
            case HTTP_FORBIDDEN:
                errorMessage = "HTTP_FORBIDDEN";
                break;
            case HTTP_GATEWAY_TIMEOUT:
                errorMessage = "HTTP_GATEWAY_TIMEOUT";
                break;
            case HTTP_GONE:
                errorMessage = "HTTP_GONE";
                break;
            case HTTP_INTERNAL_ERROR:
                errorMessage = "HTTP_INTERNAL_ERROR";
                break;
            case HTTP_NOT_ACCEPTABLE:
                errorMessage = "HTTP_NOT_ACCEPTABLE";
                break;
            case HTTP_NOT_FOUND:
                errorMessage = "HTTP_NOT_FOUND";
                break;
            case HTTP_REQ_TOO_LONG:
                errorMessage = "HTTP_REQ_TOO_LONG";
                break;
            default:
                errorMessage = "Unknown error.";
                break;
        }
        return errorMessage;
    }

    /**
     * API to construct the URL for querying to remote server based on location coordinates
     *
     * @param bound1  : location coordinate 1
     * @param bound2: location coordinate 2
     * @return URL data that can be used to query the remote server
     */
    public static String constructQueryUrl(LatLng bound1, LatLng bound2) {
        Objects.requireNonNull(bound1);
        Objects.requireNonNull(bound2);
        return "https://fake-poi-api.mytaxi.com/?p1Lat=" + bound1.latitude + "&p1Lon="
                + bound1.longitude + "&p2Lat=" + bound2.latitude + "&p2Lon=" + bound2.longitude;
    }

}
