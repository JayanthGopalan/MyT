package com.myt.challenge;

import android.util.Pair;

import com.google.android.gms.maps.model.LatLng;
import com.myt.challenge.data.VehicleFleetType;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class AppConstants {

    /**
     * Constant that represents the splash activity timeout
     */
    public static final int SPLASH_TIME_OUT = 500;

    /**
     * Constant that represents the maximum thread wait for any network operation performed
     */
    public static final int MAX_THREAD_WAIT = 60000;

    /**
     * Coordinate bounds of Hamburg, Germany that is used as a default coordinate bounds
     */
    public static final Pair<LatLng, LatLng> HAMBURG_COORDINATE_BOUNDS = new Pair<>(
            new LatLng(53.694865, 9.757589), new LatLng(53.394655, 10.099891));

    /**
     * Constant that represents the URL for querying vehicle data for Hamburg, Germany
     */
    public static final String HAMBURG_QUERY_URL_DATA = "https://fake-poi-api.mytaxi.com/?" +
            "p1Lat=53.694865&p1Lon=9.757589&p2Lat=53.394655&p2Lon=10.099891";

    /**
     * Constants that are used as as key to retrieve data from the JSON response obtained from
     * remote server
     */
    public static final String KEY_POI_LIST = "poiList";
    public static final String KEY_ID = "id";
    public static final String KEY_COORDINATE = "coordinate";
    public static final String KEY_LATITUDE = "latitude";
    public static final String KEY_LONGITUDE = "longitude";
    public static final String KEY_FLEET_TYPE = "fleetType";
    public static final String KEY_HEADING = "heading";

    /**
     * Util class that is used to generate random vehicle name for displaying on UI
     */
    public static class VehicleTitleGenerator {
        /**
         * Instance of {@link Random} for generating random numbers
         */
        private static Random sRandomGenerator = new Random();

        /**
         * Array that holds sample vehicle names for POOLING fleet type
         */
        private static final String[] POOLING_VEHICLE_TYPES = {"Honda Accord", "Toyota Camry",
                "Hyundai Sonata", "Nissan Altima", "Ford Fusion"};

        /**
         * Array that holds sample vehicle names for TAXI fleet type
         */
        private static final String[] TAXI_VEHICLE_TYPES = {"Skoda Octavia", "Volkswagen Passat",
                "Ford Mondeo", "Opel Insignia", "Toyota Avensis"};

        /**
         * List that holds sample vehicle names for POOLING fleet type
         */
        private static final List<String> POOLING_VEHICLES = Arrays.asList(POOLING_VEHICLE_TYPES);

        /**
         * List that holds sample vehicle names for TAXI fleet type
         */
        private static final List<String> TAXI_VEHICLES = Arrays.asList(TAXI_VEHICLE_TYPES);

        /**
         * API that returns random vehicle names based on Fleet type
         *
         * @param vehicleFleetType : {@link VehicleFleetType}
         * @return : Random vehicle name
         */
        public static String anyVehicle(VehicleFleetType vehicleFleetType) {
            List<String> vehicleList = vehicleFleetType == VehicleFleetType.POOLING ?
                    POOLING_VEHICLES : TAXI_VEHICLES;
            int index = sRandomGenerator.nextInt(vehicleList.size());
            String vehicleName = vehicleList.get(index);
            PrintLog.d("Random vehicle name : ", vehicleName);
            return vehicleName;
        }

    }
}
