package com.myt.challenge;

import android.app.Application;
import android.text.TextUtils;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

/**
 * Application controller class mainly for network interactions
 */
public class AppController extends Application {

    /**
     * Default tag used for sending network requests
     */
    public static final String NETWORK_REQ_TAG = AppController.class.getSimpleName();

    /**
     * {@link RequestQueue} instance operated using volley library
     */
    private RequestQueue mRequestQueue;

    /**
     * {@link Application} instance that represents the {@link AppController}
     */
    private static AppController sAppController;

    /**
     * {@inheritDoc}
     */
    @Override
    public void onCreate() {
        super.onCreate();
        sAppController = this;
    }

    /**
     * API that returns the Application instance
     *
     * @return singleton instance of {@link Application}
     */
    public static synchronized AppController getInstance() {
        return sAppController;
    }

    /**
     * API that returns the network request queue operated using Volley library
     *
     * @return network request queue {@link RequestQueue}
     */
    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }
        return mRequestQueue;
    }

    /**
     * API that adds network operations to the request queue operated using volley library
     *
     * @param req : network request
     * @param tag : tag to identify the request
     */
    public <T> void addToRequestQueue(Request<T> req, String tag) {
        // set the default tag if tag is empty
        req.setTag(TextUtils.isEmpty(tag) ? NETWORK_REQ_TAG : tag);
        getRequestQueue().add(req);
    }

    /**
     * API that adds network operations to the request queue operated using volley library
     *
     * @param req : network request
     */
    public <T> void addToRequestQueue(Request<T> req) {
        req.setTag(NETWORK_REQ_TAG);
        getRequestQueue().add(req);
    }

    /**
     * API that cancels the pending network request made previously
     *
     * @param tag : identifier of the request to be cancelled
     */
    public void cancelPendingRequests(Object tag) {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(tag);
        }
    }

}
