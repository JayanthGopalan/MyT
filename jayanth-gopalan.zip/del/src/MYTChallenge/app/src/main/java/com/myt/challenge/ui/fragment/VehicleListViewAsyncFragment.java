package com.myt.challenge.ui.fragment;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import com.ericliu.asyncexpandablelist.CollectionView;
import com.ericliu.asyncexpandablelist.async.AsyncExpandableListView;
import com.ericliu.asyncexpandablelist.async.AsyncExpandableListViewCallbacks;
import com.ericliu.asyncexpandablelist.async.AsyncHeaderViewHolder;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.myt.challenge.PrintLog;
import com.myt.challenge.R;
import com.myt.challenge.data.VehicleData;
import com.myt.challenge.data.VehicleDataProvider;
import com.myt.challenge.data.VehicleFleetType;
import com.myt.challenge.data.VehicleMetaData;

import java.util.List;

import static com.myt.challenge.data.VehicleFleetType.POOLING;
import static com.myt.challenge.data.VehicleFleetType.TAXI;

/**
 * Fragment class that shows the available vehicles in a list view filtered by categories
 */
public class VehicleListViewAsyncFragment extends MyTaxiFragmentBase implements
        AsyncExpandableListViewCallbacks<String, VehicleData>,
        VehicleDataProvider.VehicleDataProviderCallback, OnMapReadyCallback {

    private AsyncExpandableListView<String, VehicleData> mAsyncExpandableListView;
    private CollectionView.Inventory<String, VehicleData> mInventory;

    /**
     * Instance of {@link VehicleMetaData} to hold all vehicle info to be displayed on UI
     */
    public VehicleMetaData mVehicleMetaData;

    /**
     * Class level variable to track last selected category by the user
     */
    private int mGroupOrdinal;

    /**
     * Map that is used to display a vehicle which user has requested
     */
    private GoogleMap mOverlayMap;

    /**
     * {@inheritDoc}
     */
    @Override
    public int getDisplayIconId() {
        return R.drawable.vector_list;
    }

    /**
     * {@inheritDoc}
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.vehicle_list, container, false);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAsyncExpandableListView = view.findViewById(R.id.async_expandable_collection_view);
        mAsyncExpandableListView.setCallbacks(this);
        mInventory = new CollectionView.Inventory<>();
        mInventory = addInventoryData(mInventory);
        mAsyncExpandableListView.updateInventory(mInventory);
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.overlay_map);
        if (null != mapFragment) {
            mapFragment.getMapAsync(this);
        } else {
            PrintLog.e("mapFragment null in ", VehicleListViewAsyncFragment.class.getSimpleName());
        }
        if (null != getActivity()) {
            getActivity().findViewById(R.id.overlay_close).setOnClickListener((clickedView) ->
                    getActivity().findViewById(R.id.overlay_layout).setVisibility(View.GONE)
            );
        }
    }

    /**
     * API to add the categories available in the list view data shown on UI
     *
     * @param inventory : Inventory to which the categories are to be added
     * @return : Inventory to which the categories were added
     */
    private CollectionView.Inventory<String, VehicleData> addInventoryData(
            CollectionView.Inventory<String, VehicleData> inventory) {
        CollectionView.InventoryGroup<String, VehicleData> poolingGroup = inventory.newGroup(
                POOLING.ordinal());
        poolingGroup.setHeaderItem(POOLING.name());
        CollectionView.InventoryGroup<String, VehicleData> taxiGroup = inventory.newGroup(
                TAXI.ordinal());
        taxiGroup.setHeaderItem(TAXI.name());
        return inventory;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public AsyncHeaderViewHolder newCollectionHeaderView(Context context, int groupOrdinal, ViewGroup parent) {
        View headerView = LayoutInflater.from(context).inflate(
                R.layout.vehicle_data_header_row, parent, false);
        return new VehicleTypeHeaderViewHolder(headerView, groupOrdinal, mAsyncExpandableListView);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RecyclerView.ViewHolder newCollectionItemView(Context context, int groupOrdinal,
                                                         ViewGroup parent) {
        View itemView = LayoutInflater.from(context).inflate(
                R.layout.vehicle_data_row_item, parent, false);
        return new VehicleItemDataHolder(itemView);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void bindCollectionHeaderView(Context context, AsyncHeaderViewHolder holder,
                                         int groupOrdinal, String headerItem) {
        VehicleTypeHeaderViewHolder vehicleTypeHeaderViewHolder = (VehicleTypeHeaderViewHolder) holder;
        vehicleTypeHeaderViewHolder.getTextView().setText(headerItem);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void bindCollectionItemView(Context context, RecyclerView.ViewHolder holder,
                                       int groupOrdinal, VehicleData item) {
        VehicleItemDataHolder vehicleItemDataHolder = (VehicleItemDataHolder) holder;
        vehicleItemDataHolder.getTextViewTitle().setText(item.getVehicleName());
        vehicleItemDataHolder.getRatingBarView().setRating(item.getRating());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onStartLoadingGroup(int groupOrdinal) {
        mGroupOrdinal = groupOrdinal;
        if (isNetworkConnected()) {
            if ((null == (mVehicleMetaData = VehicleDataProvider.getVehicleMetaData()))
                    || (mVehicleMetaData.isEmpty())) {
                PrintLog.d("fetching data from server");
                VehicleDataProvider.fetchVehicleDataFromRemoteServer(this);
            } else {
                PrintLog.d("data available.. updating UI..");
                updateResults(groupOrdinal);
            }
        } else {
            showAlertDialog(getString(R.string.error_title), getString(R.string.no_network_connection));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onResponse(VehicleMetaData vehicleMetaData) {
        if (null != getActivity()) {
            getActivity().runOnUiThread(() -> updateResults(mGroupOrdinal));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onError(String errorMsg) {
        showAlertDialog(getString(R.string.error_title), errorMsg);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        PrintLog.d(VehicleListViewAsyncFragment.class.getSimpleName(), " :: onMapReady()");
        mOverlayMap = googleMap;
    }

    /**
     * APi to update the results on the UI based on the category that was selected by the user
     *
     * @param groupOrdinal : user selected category
     */
    private void updateResults(int groupOrdinal) {
        try {
            VehicleFleetType type = VehicleFleetType.values()[groupOrdinal];
            switch (type) {
                case POOLING:
                    new Handler().postDelayed(() -> {
                        mAsyncExpandableListView.onFinishLoadingGroup(POOLING.ordinal(),
                                mVehicleMetaData.getVehicleList(POOLING));
                    }, 5);
                    break;
                case TAXI:
                    new Handler().postDelayed(() -> {
                        mAsyncExpandableListView.onFinishLoadingGroup(TAXI.ordinal(),
                                mVehicleMetaData.getVehicleList(TAXI));
                    }, 5);
                    break;

                default:
                    PrintLog.d("Unknown VehicleFleetType.. load aborted..");
                    break;
            }
        } catch (IndexOutOfBoundsException e) {
            PrintLog.e("Unknown ordinal to map to fleetType");
        }
    }

    /**
     * View holder class for displaying the vehicle type categories
     */
    public static class VehicleTypeHeaderViewHolder extends AsyncHeaderViewHolder implements
            AsyncExpandableListView.OnGroupStateChangeListener {

        private final TextView textView;
        private final ProgressBar mProgressBar;
        private ImageView ivExpansionIndicator;

        VehicleTypeHeaderViewHolder(View headerView, int groupOrdinal,
                                    AsyncExpandableListView asyncExpandableListView) {
            super(headerView, groupOrdinal, asyncExpandableListView);
            textView = headerView.findViewById(R.id.header);
            mProgressBar = headerView.findViewById(R.id.progressBar);
            mProgressBar.getIndeterminateDrawable().setColorFilter(Color.WHITE,
                    android.graphics.PorterDuff.Mode.MULTIPLY);
            ivExpansionIndicator = headerView.findViewById(R.id.ivExpansionIndicator);
        }

        TextView getTextView() {
            return textView;
        }

        @Override
        public void onGroupStartExpending() {
            mProgressBar.setVisibility(View.VISIBLE);
            ivExpansionIndicator.setVisibility(View.INVISIBLE);
        }

        @Override
        public void onGroupExpanded() {
            mProgressBar.setVisibility(View.GONE);
            ivExpansionIndicator.setVisibility(View.VISIBLE);
            ivExpansionIndicator.setImageResource(R.drawable.ic_arrow_up);
        }

        @Override
        public void onGroupCollapsed() {
            mProgressBar.setVisibility(View.GONE);
            ivExpansionIndicator.setVisibility(View.VISIBLE);
            ivExpansionIndicator.setImageResource(R.drawable.ic_arrow_down);
        }
    }

    /**
     * View holder class for displaying the vehicle data
     */
    public class VehicleItemDataHolder extends RecyclerView.ViewHolder {

        private final TextView tvTitle;
        private final RatingBar ratingBar;

        VehicleItemDataHolder(View itemView) {
            super(itemView);
            // Define click listener for the ViewHolder's View.
            itemView.setOnClickListener((view) -> {
//                PrintLog.d("Element " + getAdapterPosition() + " clicked.");
                if (null != getActivity()) {
                    getActivity().findViewById(R.id.overlay_layout).setVisibility(View.VISIBLE);
                }
                locateVehicle(getAdapterPosition());
            });
            tvTitle = itemView.findViewById(R.id.vehicle_title);
            ratingBar = itemView.findViewById(R.id.rating_bar);
        }

        TextView getTextViewTitle() {
            return tvTitle;
        }

        RatingBar getRatingBarView() {
            return ratingBar;
        }
    }

    /**
     * API to show the location of the vehicle on map
     *
     * @param position : list item position that the user has requested to view
     */
    private void locateVehicle(int position) {
        if (null != mVehicleMetaData) {
            List<VehicleData> vehicleDataList;
            if (mGroupOrdinal == TAXI.ordinal()) {
                vehicleDataList = mVehicleMetaData.getVehicleList(TAXI);
            } else {
                vehicleDataList = mVehicleMetaData.getVehicleList(POOLING);
            }
            if (position < vehicleDataList.size()) {
                VehicleData vehicleData = vehicleDataList.get(position);
                PrintLog.d("vehicleData :: ", vehicleData);
                if (null != mOverlayMap) {
                    MapUtil.locateOnMap(getContext(), mOverlayMap, vehicleData.getLocation(), "",
                            vehicleData.getFleetType().name(), (float) vehicleData.getHeading());
                }
            } else {
                PrintLog.e("Invalid position index");
            }
        }
    }

}
