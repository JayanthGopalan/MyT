package com.myt.challenge.ui.fragment;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;

import com.myt.challenge.R;

/**
 * Base class for the fragments used in {@link com.myt.challenge.ui.activity.MyTaxiMainScreen}
 */
public abstract class MyTaxiFragmentBase extends Fragment {

    /**
     * APi to get the icon that is to be displayed for a tab on the UI
     *
     * @return
     */
    public abstract int getDisplayIconId();

    /**
     * API to show alert dialog
     *
     * @param title   : title of the alert dialog
     * @param message : short description about the alert
     */
    protected void showAlertDialog(String title, String message) {
        if (null != getActivity()) {
            getActivity().runOnUiThread(() -> {
                if (!getActivity().isFinishing()) {
                    new AlertDialog.Builder(getActivity())
                            .setTitle(title)
                            .setMessage(message)
                            .setCancelable(false)
                            .setNegativeButton(getString(R.string.dismiss), (dialog, which) ->
                                    dialog.dismiss()).show();
                }
            });
        }
    }

    /**
     * API to check if the device is connected to internet or not
     *
     * @return true if network is connected else false.
     */
    protected boolean isNetworkConnected() {
        if (null != getContext()) {
            ConnectivityManager connectivityManager
                    = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return ((activeNetworkInfo != null) && (activeNetworkInfo.isConnected()));
        }
        return false;
    }

}
