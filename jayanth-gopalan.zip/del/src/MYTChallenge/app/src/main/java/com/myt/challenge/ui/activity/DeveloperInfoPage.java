package com.myt.challenge.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;

import com.myt.challenge.R;

/**
 * Activity that displays developer info
 */
public final class DeveloperInfoPage extends AppCompatActivity {

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.developer_info_page);
        if (null != getActionBar()) {
            getActionBar().setTitle(R.string.about_developer);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onStart() {
        Button viewSolutionsButton = findViewById(R.id.view_solutions);
        viewSolutionsButton.setOnClickListener((v) -> {
            // Open the Answers page
            Intent solutionPage = new Intent(getApplicationContext(), MyTaxiMainScreen.class);
            startActivity(solutionPage);
        });
        super.onStart();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onBackPressed() {
        finish();
    }

}
