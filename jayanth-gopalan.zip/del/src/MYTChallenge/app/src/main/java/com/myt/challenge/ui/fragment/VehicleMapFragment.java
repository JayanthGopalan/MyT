package com.myt.challenge.ui.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.myt.challenge.PrintLog;
import com.myt.challenge.R;
import com.myt.challenge.data.VehicleData;
import com.myt.challenge.data.VehicleDataProvider;
import com.myt.challenge.data.VehicleMetaData;

import java.util.List;

import static com.google.android.gms.maps.model.BitmapDescriptorFactory.HUE_GREEN;
import static com.google.android.gms.maps.model.BitmapDescriptorFactory.HUE_ORANGE;
import static com.google.android.gms.maps.model.BitmapDescriptorFactory.HUE_RED;

/**
 * Class that displays all the available vehicles on the map
 */
public class VehicleMapFragment extends MyTaxiFragmentBase implements OnMapReadyCallback,
        GoogleMap.OnCameraIdleListener, VehicleDataProvider.VehicleDataProviderCallback,
        SwipeRefreshLayout.OnRefreshListener {

    /**
     * {@link SwipeRefreshLayout} to update the map
     */
    private SwipeRefreshLayout mSwipeRefreshLayout;

    /**
     * {@link GoogleMap} to display the vehicles on map
     */
    private GoogleMap mMap;

    /**
     * {@inheritDoc}
     */
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.vehicle_maps, container, false);
        // SwipeRefreshLayout
        mSwipeRefreshLayout = rootView.findViewById(R.id.map_swipe_refresh_layout);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary,
                android.R.color.holo_green_dark,
                android.R.color.holo_orange_dark,
                android.R.color.holo_blue_dark);
        return rootView;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onStart() {
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map);
        if (null != mapFragment) {
            mapFragment.getMapAsync(this);
        } else {
            PrintLog.e("mapFragment found null");
        }
        super.onStart();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        PrintLog.d("onMapReady()");
        mMap = googleMap;
        mMap.setOnCameraIdleListener(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        PrintLog.d(VehicleMapFragment.class.getSimpleName(), ".. isVisibleToUser :: "
                + isVisibleToUser);
        if (isVisibleToUser) {
            MapUtil.zoomToHamburgBounds(mMap);
            if (isNetworkConnected()) {
                VehicleMetaData vehicleMetaData = VehicleDataProvider.getVehicleMetaData();
                if ((null == vehicleMetaData) || (vehicleMetaData.isEmpty())) {
                    mSwipeRefreshLayout.setRefreshing(true);
                    VehicleDataProvider.fetchVehicleDataFromRemoteServer(this);
                    return;
                }
                updateResultsOnMap(vehicleMetaData);
            } else {
                showAlertDialog(getString(R.string.error_title), getString(R.string.no_network_connection));
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    public int getDisplayIconId() {
        return R.drawable.vector_car;
    }

    /**
     * API to update the vehicle results on the map using markers
     *
     * @param vehicleMetaData : available vehicle data from remote server
     */
    private void updateResultsOnMap(VehicleMetaData vehicleMetaData) {
        if (null != vehicleMetaData) {
            addMarkersToMap(mMap, vehicleMetaData.getAllVehicleData());
        }
    }

    /**
     * API to add marker on map as per the data fetched from remote server
     *
     * @param map             : {@link GoogleMap}
     * @param vehicleDataList : available vehicle data from remote server
     */
    private void addMarkersToMap(GoogleMap map, List<VehicleData> vehicleDataList) {
        if (null != map) {
            map.clear();
            for (VehicleData vehicleData : vehicleDataList) {
                BitmapDescriptor bitmapMarker;
                switch (vehicleData.getFleetType()) {
                    case TAXI:
                        bitmapMarker = BitmapDescriptorFactory.defaultMarker(HUE_ORANGE);
                        break;
                    case POOLING:
                        bitmapMarker = BitmapDescriptorFactory.defaultMarker(HUE_GREEN);
                        break;
                    default:
                        bitmapMarker = BitmapDescriptorFactory.defaultMarker(HUE_RED);
                        break;
                }
                map.addMarker(new MarkerOptions().position(vehicleData.getLocation()).title(
                        vehicleData.getVehicleName()).snippet(vehicleData.getFleetType().name())
                        .icon(bitmapMarker));
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onResponse(VehicleMetaData vehicleMetaData) {
        if (null != mSwipeRefreshLayout) {
            mSwipeRefreshLayout.setRefreshing(false);
        }
        if (null != getActivity()) {
            getActivity().runOnUiThread(() -> updateResultsOnMap(vehicleMetaData));
        } else {
            PrintLog.e("Activity was null..  hence UI update ignored");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onError(String errorMsg) {
        if (null != mSwipeRefreshLayout) {
            mSwipeRefreshLayout.setRefreshing(false);
        }
        showAlertDialog(getString(R.string.error_title), errorMsg);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onRefresh() {
        PrintLog.d(VehicleMapFragment.class.getSimpleName(), " :: onRefresh()");
        updateMap();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onCameraIdle() {
        if (getUserVisibleHint()) {
            if (null != mSwipeRefreshLayout) {
                mSwipeRefreshLayout.setRefreshing(true);
            }
            updateMap();
        }
    }

    /**
     * API to update the map as per user request
     */
    private void updateMap() {
        if (isNetworkConnected()) {
            Pair<LatLng, LatLng> mapBounds = getMapBounds();
            VehicleDataProvider.fetchVehicleDataFromRemoteServer(VehicleDataProvider
                    .constructQueryUrl(mapBounds.first, mapBounds.second), this);
        } else {
            showAlertDialog(getString(R.string.error_title), getString(R.string.no_network_connection));
        }
    }

    /**
     * API to get the bounds of the map visible on screen
     *
     * @return bounds of the map wrapped in {@link Pair}
     */
    private Pair<LatLng, LatLng> getMapBounds() {
        LatLng northEast = mMap.getProjection().getVisibleRegion().latLngBounds.northeast;
        LatLng southWest = mMap.getProjection().getVisibleRegion().latLngBounds.southwest;
        PrintLog.d("Bounds identified as northEast ::", northEast, " \n and southWest ::", southWest);
        return new Pair<>(northEast, southWest);
    }

}
